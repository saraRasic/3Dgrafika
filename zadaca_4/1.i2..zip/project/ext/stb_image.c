#define STB_IMAGE_IMPLEMENTATION
#include <libraries/stb_image.h>